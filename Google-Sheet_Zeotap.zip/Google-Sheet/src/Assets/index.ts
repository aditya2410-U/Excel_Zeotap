import LoadingScreenPatch from './Images/loaderIcon.svg'
import GoogleSheetLogo from './Images/GoogleSheet.png'

const ImageLinks = {
    _LoadingScreen : LoadingScreenPatch,
    _GoogleSheetLogo : GoogleSheetLogo,
}

export default ImageLinks;